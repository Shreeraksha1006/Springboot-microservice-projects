package com.raksha.springkafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringkafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
